// CRM Studio Scanner - popup: a checklist of sections the scanner looks for by clicking around the site.

// The standard checklist. "words" match the text (or address) of a link, button or menu entry.
// popup: the section usually opens as a pop-up from a button. details: open rules, levels, cards on that page.
const DEFAULT_SECTIONS = [
  // the sections of the competitor review (on by default)
  { key: "promotions", label: "Promotions", words: "promo|promotion|bonus(es)?\\b|offers?\\b|campaigns?\\b|angebot|aktion|promociones|ofertas|promozioni|offres|aanbieding|kampanj|kampanya", not: "^my\\b|terms|conditions|rules|requirement|shop|welcome", details: true, cards: "Offer" },
  { key: "deposit", label: "Deposit / cashier", words: "^(deposit|deposit now|wallet|cashier|einzahlen|einzahlung|kasse|depositar|depósito|deposita|dépôt|déposer)$", popup: true, loggedIn: true },
  { key: "vip", label: "Loyalty / VIP", words: "\\bvip\\b|loyal|club\\b|rewards?\\b|levels?\\b|rakeback|cashback|treue|fidelidad|fedelt|fidélité", not: "shop|store", details: true },
  { key: "tournaments", label: "Tournaments", words: "tourn|turnier|torneo|tournoi|leaderboard|rangliste|\\brace\\b|races\\b|drops?[\\s_&-]*(and|&)?[\\s_-]*wins|prize[\\s_-]*drop|wettbewerb", details: true },
  { key: "missions", label: "Missions", words: "mission|quest|achievement|badges?\\b|challenges?\\b", details: true },
  { key: "shop", label: "Store", words: "\\bshop\\b|\\bstore\\b|bonus[\\s_-]*shop|rewards?[\\s_-]*shop|exchange|marketplace|prämien|tienda", not: "app[\\s_-]*store|play[\\s_-]*store|google[\\s_-]*play", details: true },
  // more sections, off unless you tick them
  { key: "register", label: "Sign-up", words: "^(register|registrieren|sign[\\s_-]*up|signup|join( now)?|open account|create[\\s_-]*(an[\\s_-]*)?account|konto[\\s_-]*erstellen|registrati|inscri.*|regístrate|registrarse)$", popup: true, loggedOut: true, off: true },
  { key: "welcome", label: "Welcome offer", words: "welcome|new[\\s_-]*player|first[\\s_-]*deposit|1st[\\s_-]*deposit|willkommen|bienvenid|benvenut|bienvenue", not: "terms|conditions|rules|requirement", details: true, content: true, off: true },
  { key: "terms", label: "Bonus terms", words: "bonus[\\s_-]*(t&cs?|terms|rules|conditions|policy|requirement)|promotion[\\s_-]*(terms|rules|requirement)|wagering[\\s_-]*requirement|bonusbedingungen|bonus[\\s_-]*regeln|bonusvoorwaarden|terms[\\s_-]*(and|&)[\\s_-]*conditions", details: true, help: true, off: true },
  { key: "wheel", label: "Wheel / mini-games", words: "wheel|lucky[\\s_-]*spin|daily[\\s_-]*(spin|reward|bonus|drop)|mystery[\\s_-]*(box|chest|bonus)|scratch|mini[\\s_-]*games?|treasure|\\bchests?\\b", details: true, off: true },
  { key: "referral", label: "Refer a friend", words: "refer|referral|invite[\\s_-]*(a[\\s_-]*)?friends?|bring[\\s_-]*a[\\s_-]*friend|freunde[\\s_-]*werben|invita", details: true, off: true },
  { key: "jackpots", label: "Jackpots", words: "jackpot", details: true, off: true },
  { key: "sports", label: "Sports promos", words: "free[\\s_-]*bets?|acca|odds[\\s_-]*boost|price[\\s_-]*boost|bet[\\s_-]*insurance|bet[\\s_-]*builder|sports?[\\s_-]*(promo|promotions|bonus|offers?)", details: true, off: true, content: true },
  { key: "bonuses", label: "My bonuses", words: "my[\\s_-]*(bonus(es)?|rewards|offers|free[\\s_-]*spins)|bonus[\\s_-]*(wallet|balance|history)|active[\\s_-]*bonus|free[\\s_-]*spins\\b|freespins", details: true, loggedIn: true, off: true },
  { key: "inbox", label: "Inbox / messages", words: "inbox|messages?\\b|notifications?\\b|mailbox|postfach|nachrichten", loggedIn: true, off: true },
  { key: "account", label: "Account / profile", words: "my[\\s_-]*account|my[\\s_-]*profile|^profile$|account[\\s_-]*settings|communication|marketing[\\s_-]*preferences|preferences|mein[\\s_-]*konto|mi[\\s_-]*cuenta", loggedIn: true, off: true },
  { key: "withdrawal", label: "Withdrawal", words: "^(withdraw|withdrawal|withdraw funds|auszahlen|auszahlung|retirar|retiro|prelevare|prelievo|retrait)$", popup: true, loggedIn: true, off: true },
  { key: "rg", label: "Responsible gambling", words: "responsible|safer[\\s_-]*gambling|player[\\s_-]*protection|verantwort|juego[\\s_-]*responsable|gioco[\\s_-]*responsabile|jeu[\\s_-]*responsable", help: true, off: true },
  { key: "app", label: "App", words: "\\bapp\\b|download[\\s_-]*(the[\\s_-]*)?app|mobile[\\s_-]*app", off: true },
  { key: "help", label: "Help / FAQ", words: "^(help|help cent(er|re)|support|faq|faqs)$", help: true, off: true }
];
const PROMO = DEFAULT_SECTIONS.find((x) => x.key === "promotions");
// the planner's website sections for each checklist entry: unticked ones are left out of the import too
const KINDS = { homepage: ["homepage"], menu: ["navigation"], register: ["registration"], deposit: ["deposit"], promotions: ["promotions"], tournaments: ["tournament"], vip: ["loyalty"], missions: ["missions"], shop: ["shop"], wheel: ["wheel"], referral: ["referral"], bonuses: ["account"], inbox: ["inbox"], account: ["account"], withdrawal: ["withdrawal"], app: ["app"], rg: ["rg"] };
const GROUPS = { promotions: "Review sections", register: "More (optional)" };
// Which sections belong to which run: logged-in only ones are hidden on a logged-out run and the other way round.
const fits = (s) => !(runMode === "logged-out" && s.loggedIn) && !(runMode === "logged-in" && s.loggedOut);
// Menu entries that are game categories or account basics; not worth suggesting.
const NOT_SUGGESTED = /^(home|casino|live( casino| dealer)?|sports?( ?book| ?betting)?|withdraw(al)?|help( cent(er|re))?|support|faqs?|slots?|table games|new( games)?|popular|top( games)?|all games|games|jackpots? games|roulette|blackjack|baccarat|poker|crash( games)?|instant( games)?|megaways|providers?|search|favou?rites|recent(ly played)?|log ?in|sign ?in|log ?out|register|sign ?up|join( now)?|deposit|wallet|cashier|menu|close|back|english|deutsch|español|language|light|dark|en|de|es|fr|it)$/i;

const main = document.getElementById("main");
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const reEsc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
let runMode = "logged-out", guessed = false;
let site = { sugg: [], pages: [] }; // this site's own ticks, kept per site
let info0 = {};
let target = null, prefs = { off: [], on: [], custom: [] }, sections = [], suggestions = [], pages = [], base = [];

// Search words typed by the person ("daily wheel, lucky spin") become a pattern.
function wordsFrom(name, extra) {
  const parts = [name].concat(String(extra || "").split(",")).map((p) => p.trim()).filter(Boolean);
  return parts.map((p) => reEsc(p.toLowerCase()).replace(/\s+/g, "[\\s_-]*")).join("|");
}

// Runs inside the operator's page: opens a collapsed menu, then lists links, buttons and the menu.
async function collectSite() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const vis = (el) => { const r = el.getBoundingClientRect(); return r.width > 2 && r.height > 2; };
  const textOf = (el) => (el.innerText || el.getAttribute("aria-label") || el.title || "").trim().replace(/\s+/g, " ");
  const toggles = Array.from(document.querySelectorAll("button, [role=button], a")).filter((b) => {
    if (!vis(b) || b.getAttribute("aria-expanded") === "true") return false;
    const label = (b.getAttribute("aria-label") || b.title || b.innerText || "").toLowerCase();
    const cls = String(b.className || "").toLowerCase();
    return /^(menu|open menu|toggle menu|toggle sidebar|open sidebar|sidebar|navigation|main menu|☰)$/.test(label.trim()) || /hamburger|burger|menu-toggle|sidebar-toggle|nav-toggle/.test(cls) || (b.getAttribute("aria-expanded") === "false" && /menu|nav|sidebar/.test(label + " " + cls + " " + (b.getAttribute("aria-controls") || "")));
  });
  let opened = false;
  for (const t of toggles.slice(0, 1)) { try { t.click(); opened = true; } catch (e) { /* ignore */ } }
  if (opened) await sleep(700);
  const links = Array.from(document.querySelectorAll("a[href]")).filter((a) => /^https?:/i.test(a.href)).map((a) => ({ text: textOf(a).slice(0, 80), href: a.href }));
  const buttons = Array.from(document.querySelectorAll("button, [role=button], a:not([href]), a[href='#'], a[href^='javascript']")).filter(vis).map((b) => textOf(b)).filter((t) => t && t.length <= 30);
  const seen = new Set(), menu = [];
  document.querySelectorAll("nav a, aside a, header a, [role=navigation] a, [class*=sidebar] a, [class*=Sidebar] a, nav button, aside button, [class*=sidebar] button, [role=menuitem]").forEach((el) => {
    const t = textOf(el).slice(0, 40); if (!t || seen.has(t.toLowerCase()) || !vis(el)) return;
    seen.add(t.toLowerCase()); menu.push({ text: t, href: el.href || "" });
  });
  // Signs of being logged in or out. Hidden menu entries count too (a "Log out" link in a closed menu).
  const login = { inScore: 0, outScore: 0, inWhy: [], outWhy: [] };
  const all = Array.from(document.querySelectorAll("a, button, [role=button], [role=menuitem]"));
  const shownText = all.filter(vis).map(textOf).map((t) => t.trim());
  const anyText = all.map((el) => (el.textContent || el.getAttribute("aria-label") || "").trim().replace(/\s+/g, " "));
  const sign = (side, pts, why) => { login[side + "Score"] += pts; login[side + "Why"].push(why); };
  if (anyText.some((t) => /^(log ?out|sign ?out|logout|abmelden|ausloggen|cerrar sesión|salir|déconnexion|esci|uitloggen)$/i.test(t))) sign("in", 3, "a Log out option");
  if (shownText.some((t) => /^(log ?in|sign ?in|login|anmelden|einloggen|iniciar sesión|entrar|connexion|se connecter|accedi|inloggen)$/i.test(t))) sign("out", 3, "a Log in button");
  if (shownText.some((t) => /^(register|sign ?up|join( now)?|create account|open account|registrieren|regístrate|registrati|s'inscrire)$/i.test(t))) sign("out", 1, "a Register button");
  if (Array.from(document.querySelectorAll("input[type=password]")).some(vis)) sign("out", 1, "a password field");
  if (shownText.some((t) => /^(deposit|deposit now|wallet|cashier|einzahlen|depositar)$/i.test(t))) sign("in", 1, "a Deposit button");
  // a balance near the top of the page, like "€12.50" or "0.00 USDT"
  const money = /^([€$£₺₹¥₽]|EUR|USD|GBP|CAD|AUD|NZD|BTC|ETH|USDT)?\s?\d{1,7}([.,]\d{2,8})\s?([€$£₺₹¥₽]|EUR|USD|GBP|CAD|AUD|NZD|BTC|ETH|USDT|mBTC)?$/i;
  const balance = Array.from(document.querySelectorAll("header *, [class*=header] *, [class*=Header] *, [class*=balance] *, [class*=Balance], [class*=balance]")).some((el) => {
    if (!vis(el) || el.children.length > 2) return false;
    const r = el.getBoundingClientRect(), t = (el.innerText || "").trim();
    return r.top < 160 && t.length <= 20 && money.test(t) && /[€$£₺₹¥₽]|[A-Z]{3}/i.test(t);
  });
  if (balance) sign("in", 2, "a balance in the header");
  const avatar = Array.from(document.querySelectorAll("header button, header a, header [role=button], [class*=header] button, [class*=Header] button")).some((b) => vis(b) &&
    /avatar|profile|account|user[-_ ]?menu|\buser\b/i.test((b.getAttribute("aria-label") || "") + " " + (b.title || "") + " " + String(b.className || "")) && !/log ?in|sign ?in|register/i.test(b.innerText || ""));
  if (avatar) sign("in", 1, "an account button");
  // where the site's logo links to: almost always the homepage (often a language version like /en)
  const logo = Array.from(document.querySelectorAll("header a[href], [class*=header] a[href], [class*=Header] a[href], nav a[href], a[class*=logo], a[class*=Logo], a[aria-label*=home i]")).find((a) =>
    vis(a) && (/logo|brand|home/i.test(String(a.className || "") + " " + (a.getAttribute("aria-label") || "") + " " + (a.id || "")) || (a.querySelector("img, svg") && !(a.innerText || "").trim())));
  return { login, logoHref: logo ? logo.href : "", url: location.href, title: document.title, host: location.hostname, origin: location.origin, path: location.pathname, links, buttons: Array.from(new Set(buttons)), menu: menu.slice(0, 80), menuOpened: opened };
}

function clean(u) { try { const x = new URL(u); x.hash = ""; return x.toString(); } catch (e) { return ""; } }
function shortText(t) { t = (t || "").replace(/\$?[\d.,]{4,}/g, "").replace(/\s+/g, " ").trim(); return t.length > 40 ? t.slice(0, 40) + "…" : t; }

// A quick look at what's visible now, to show next to each section. The real search happens during the scan.
function seenOnPage(sec, info) {
  const re = new RegExp(sec.words, "i"), no = sec.not ? new RegExp(sec.not, "i") : null;
  const ok = (t) => t && t.length <= 40 && re.test(t) && !(no && no.test(t));
  const b = info.buttons.find(ok);
  if (b) return b;
  const l = info.links.find((x) => ok(x.text));
  return l ? l.text : "";
}

function build(info) {
  // A homepage can be "/", a language version ("/en", "/de-de/") or wherever the logo links to.
  const here = clean(info.url), langHome = /^\/([a-z]{2}([-_][a-z]{2})?)\/?$/i;
  let home = clean(info.origin + "/");
  let logoHere = false;
  try {
    const lu = new URL(info.logoHref);
    if (lu.origin === info.origin && (lu.pathname === "/" || langHome.test(lu.pathname))) home = clean(lu.origin + lu.pathname);
    // the logo links to the page you're on: this is the homepage, whatever its address
    if (lu.origin === info.origin && clean(lu.origin + lu.pathname) === clean(info.origin + info.path)) { logoHere = true; home = clean(lu.origin + lu.pathname); }
  } catch (e) { /* no logo link */ }
  const onHome = info.path === "/" || info.path === "" || langHome.test(info.path) || logoHere || here === home;
  if (onHome) home = here.replace(/[?#].*$/, "") || here;
  const keep = (cat) => prefs.off.indexOf("base:" + cat) < 0;
  base = [{ type: "page", url: home, cat: "homepage", label: "Homepage", sub: "", checked: keep("homepage") }];
  if (!onHome) base.push({ type: "page", url: here, cat: "current", label: "This page", sub: shortText(info.title), checked: keep("current") });
  if (info.menu.length >= 3) base.push({ type: "menu", url: home, cat: "menu", label: "Site menu", sub: info.menu.length + " entries", menu: info.menu, checked: keep("menu") });
  let grp = "";
  sections = DEFAULT_SECTIONS.concat(prefs.custom.map((c) => Object.assign({ details: true, custom: true }, c))).map((s) => Object.assign({}, s, { group: s.custom ? "Your own" : (grp = GROUPS[s.key] || grp), checked: s.off ? prefs.on.indexOf(s.key) >= 0 : prefs.off.indexOf(s.key) < 0, seen: seenOnPage(s, info) }));
  // menu entries no section covers become suggestions
  const res = sections.map((s) => new RegExp(s.words, "i"));
  const taken = new Set();
  suggestions = info.menu.filter((m) => {
    const t = m.text.trim(), k = t.toLowerCase();
    if (t.length < 3 || t.length > 30 || /\d{3,}/.test(t) || NOT_SUGGESTED.test(t) || taken.has(k) || res.some((r) => r.test(t))) return false;
    taken.add(k); return true;
  }).slice(0, 12).map((m) => ({ key: "s_" + m.text.toLowerCase().replace(/[^a-z0-9]+/g, "_"), label: m.text, words: "^" + reEsc(m.text) + "$", details: true, checked: false, seen: m.text }));
  suggestions.forEach((x) => { x.checked = site.sugg.indexOf(x.key) >= 0; });
  pages = site.pages.map((u) => ({ type: "page", url: u.url, cat: "custom", label: "Added by you", sub: u.sub, checked: u.checked !== false }));
}

async function savePrefs() { await chrome.storage.sync.set({ sectionPrefs: prefs }); }
// ticks that only make sense on one site (its menu suggestions, links you pasted) are kept per site
async function saveSite() {
  site = { sugg: suggestions.filter((x) => x.checked).map((x) => x.key), pages: pages.map((p) => ({ url: p.url, sub: p.sub, checked: p.checked })) };
  const all = (await chrome.storage.local.get("siteTicks")).siteTicks || {};
  all[target.info.host] = site;
  await chrome.storage.local.set({ siteTicks: all });
}

function row(item, list, i, extra) {
  const sub = item.type === "page" || item.type === "menu" ? (item.sub ? '<span class="cat">' + esc(item.sub) + "</span>" : "") : "";
  const small = list === "b" ? (item.type === "menu" ? "Opens the menu on the homepage" : item.url)
    : list === "x" ? "Seen in the menu"
    : list === "p" ? item.url
    : item.seen ? "Seen on this page: “" + shortText(item.seen) + "”" : item.popup ? "Will look for the button" : "Will search the page and menus";
  return '<div class="item"><label><input type="checkbox" data-list="' + list + '" data-i="' + i + '"' + (item.checked ? " checked" : "") + "><span><b>" + esc(item.label) + "</b> " + sub + "<small>" + esc(small) + "</small></span></label>" + (extra || "") + "</div>";
}

// The website review (all sections at once) is switched off for now. Set this to true to bring it back.
const SHOW_REVIEW = false;
// The part scans (one part per scan) are switched off: the research scan does it all. Set to true to bring them back.
const SHOW_PARTS = false;
// Where a research scan looks besides the review sections: general terms, payments, help, about.
const RESEARCH_EXTRA = [
  { key: "generalterms", label: "Terms & conditions", words: "^(terms|terms (and|&) conditions|general terms|t&cs?|terms of (use|service))$|terms[\\s_-]*(and|&)?[\\s_-]*conditions|general[\\s_-]*terms", not: "bonus|promotion", help: true },
  { key: "payments", label: "Payments", words: "payment[\\s_-]*methods?|^payments?$|banking|deposits?[\\s_-]*(and|&)[\\s_-]*withdrawals?|cashier[\\s_-]*info", help: true },
  { key: "about", label: "About", words: "^about( us)?$|about[\\s_-]*us|who we are", help: true }
];
// One part per scan: promotions with their terms, or one feature of the casino in depth.
const PARTS = [["promos", "Promotions & terms"], ["vip", "Loyalty / VIP"], ["missions", "Missions"], ["deposit", "Deposit / cashier"], ["tournaments", "Tournaments"], ["shop", "Store"], ["custom", "Something else…"]];
const PART_NOTE = {
  vip: "Finds the loyalty or VIP page and photographs it top to bottom, its tabs, and its details: levels, how to progress, rewards.",
  missions: "Finds the missions and photographs them with their tabs (available, locked, completed) and opens their details.",
  deposit: "Opens the cashier, photographs it, the step after choosing a payment method, and the Withdraw / History tabs. It never pays. Log in first: the cashier only opens for players.",
  tournaments: "Finds the tournaments, races or leaderboards and opens each one (up to 15): rules, prizes, leaderboard.",
  shop: "Finds the store (bonus shop, rewards store) and photographs it with its tabs and item details.",
  custom: "Name the feature (e.g. Wheel of Fortune, Bonus Crab, Daily Drop) and any other names it may have. The scanner looks for it and photographs it with its tabs and details."
};
function partOf() { const m = prefs.mode; return PARTS.some((p) => p[0] === m) ? m : (SHOW_REVIEW && m === "review" ? "review" : "promos"); }
function partSwitch() {
  const m = partOf();
  return "<h2>What to scan</h2>" + '<select id="partSel" style="width:100%">' + (SHOW_REVIEW ? '<option value="review"' + (m === "review" ? " selected" : "") + ">Website review (all sections)</option>" : "") +
    PARTS.map((p) => '<option value="' + p[0] + '"' + (m === p[0] ? " selected" : "") + ">" + esc(p[1]) + "</option>").join("") + "</select>";
}
// One scan that researches the whole casino: market, products, payments, offers.
function renderResearch() {
  main.innerHTML = "<h2>Research the casino</h2>" + runSwitch() +
    '<p class="note">Reads the homepage and its footer (licence, company, payment and provider logos), the terms, payments, help and responsible-gambling pages, the promotions, loyalty / VIP, missions, tournaments and store, the cashier when you are logged in, and menu entries that fit none of these (a wheel, refer a friend…). CRM Studio then builds the casino\'s profile: market and licence, products and games, payments, offers and retention.</p>' +
    '<label class="opt"><input type="checkbox" id="openCards"' + (prefs.cards !== false ? " checked" : "") + '><span><b>Open every promotion</b><small>Reads each promotion\'s terms and banner (up to 30). Adds about 10 seconds per promotion.</small></span></label>' +
    blurField() +
    '<button class="primary" id="go">Research this casino</button>' +
    "<p class=\"note\">Takes a few minutes. Don't switch tabs until CRM Studio opens. Log in first if you want the cashier and your account's view of the loyalty programme.</p>";
}
function renderPart() {
  const k = partOf(), label = PARTS.find((p) => p[0] === k)[1];
  main.innerHTML = partSwitch() + runSwitch() + '<p class="note">' + esc(PART_NOTE[k] || "") + "</p>" +
    (k === "custom" ? '<label class="opt" style="display:block"><span><b>Feature name</b></span><input type="text" id="partName" value="' + esc(prefs.partName || "") + '" placeholder="e.g. Wheel of Fortune" style="width:100%;margin-top:6px"><span><small>Other names it may have (optional, comma separated)</small></span><input type="text" id="partWords" value="' + esc(prefs.partWords || "") + '" placeholder="e.g. lucky wheel, daily spin" style="width:100%;margin-top:6px"></label>' : "") +
    blurField() +
    '<button class="primary" id="go">Scan ' + esc(k === "custom" ? (prefs.partName || "the feature") : label) + "</button>" +
    "<p class=\"note\">Don't switch tabs until CRM Studio opens. CRM Studio writes it up: what it is, how it works and its key details.</p>";
}
// two kinds of scan: the website review (sections), or every promotion with its terms
function modeSwitch() {
  if (!SHOW_REVIEW) return partSwitch();
  const m = prefs.mode === "promos" ? "promos" : "review";
  return "<h2>What to scan</h2>" + '<div class="seg"><label><input type="radio" name="mode" value="review"' + (m === "review" ? " checked" : "") + '><span>Website review</span></label><label><input type="radio" name="mode" value="promos"' + (m === "promos" ? " checked" : "") + "><span>Promotions & terms</span></label></div>";
}
function runSwitch() {
  return "<h2>This run is</h2>" + '<div class="seg"><label><input type="radio" name="run" value="logged-out"' + (runMode === "logged-out" ? " checked" : "") + '><span>Logged out</span></label><label><input type="radio" name="run" value="logged-in"' + (runMode === "logged-in" ? " checked" : "") + "><span>Logged in</span></label></div>" +
    (guessed ? '<p class="note">' + esc(guessed) + "</p>" : "");
}
function blurField() {
  return '<label class="opt" style="display:block"><span><b>Blur on screenshots</b><small>Email addresses are blurred automatically. Add your username or name here, separated by commas.</small></span><input type="text" id="blurWords" value="' + esc(prefs.blur || "") + '" placeholder="your username, your name" style="width:100%;margin-top:6px"></label>';
}
function renderPromos() {
  main.innerHTML = modeSwitch() + runSwitch() +
    '<p class="note">Finds the promotions page and opens every promotion one by one (up to 30): its pop-up or page, More info or the ⓘ icon, and the terms inside. CRM Studio then writes up each one: what it does, how it works and its terms, as a list.</p>' +
    '<label class="opt"><input type="checkbox" id="promoTerms"' + (prefs.promoTerms === true ? " checked" : "") + '><span><b>Also read the general bonus terms</b><small>The page most promotions refer to. Its text is kept, not its screenshots.</small></span></label>' +
    blurField() +
    '<button class="primary" id="go">Scan promotions</button>' +
    '<p class="note">About 10 seconds per promotion. Don\'t switch tabs until CRM Studio opens.</p>';
}
function render() {
  if (!SHOW_REVIEW && !SHOW_PARTS) { renderResearch(); return; }
  const part = partOf();
  if (part === "promos") { renderPromos(); return; }
  if (part !== "review") { renderPart(); return; }
  let lastGroup = "";
  main.innerHTML = modeSwitch() +
    "<h2>This run is</h2>" +
    '<div class="seg"><label><input type="radio" name="run" value="logged-out"' + (runMode === "logged-out" ? " checked" : "") + '><span>Logged out</span></label><label><input type="radio" name="run" value="logged-in"' + (runMode === "logged-in" ? " checked" : "") + "><span>Logged in</span></label></div>" +
    (guessed ? '<p class="note">' + esc(guessed) + "</p>" : "") +
    '<label class="opt"><input type="checkbox" id="openCards"' + (prefs.cards === true ? " checked" : "") + '><span><b>Open every promotion</b><small>Only needed for offer terms: the review compares how pages are set up. About 10 seconds more per offer.</small></span></label>' +
    blurField() +
    "<h2>Always</h2>" +
    '<div class="list">' + base.map((p, i) => row(p, "b", i)).join("") + "</div>" +
    "<h2>Sections to find</h2>" +
    '<div class="list">' + sections.map((s, i) => { if (!fits(s)) return ""; const g = s.group !== lastGroup ? '<div class="grp">' + esc(s.group) + "</div>" : ""; lastGroup = s.group; return g + row(s, "s", i, s.custom ? '<button class="x" data-rm="' + i + '" title="Remove from my list" aria-label="Remove ' + esc(s.label) + '">✕</button>' : ""); }).join("") + pages.map((p, i) => row(p, "p", i)).join("") + "</div>" +
    '<details id="addbox"><summary>+ Add a section to my list</summary>' +
    '<div class="col"><input type="text" id="newName" placeholder="Name, e.g. Daily wheel" maxlength="40"><input type="text" id="newWords" placeholder="Other words it may be called (optional, comma separated)" maxlength="200"><button id="addSec">Add to my list</button></div>' +
    '<div class="row"><input type="url" id="extra" placeholder="Or paste a page link for this scan"><button id="add">Add</button></div></details>' +
    (suggestions.length ? "<h2>Also on this site</h2><p class=\"note\">Menu entries none of your sections cover. Tick any you want scanned too.</p>" +
      '<div class="list">' + suggestions.map((s, i) => row(s, "x", i, '<button class="x keep" data-keep="' + i + '" title="Add to my list for every site">Keep</button>')).join("") + "</div>" : "") +
    '<button class="primary" id="go"></button>' +
    '<p class="note">For each section it clicks around the site: the page, the side menu, sub-menus and (logged in) the account menu. Then it photographs what opens and, on VIP, promotions and similar pages, opens the details. Sections it can\'t find are listed in CRM Studio. About 15 to 40 seconds per section; don\'t switch tabs until CRM Studio opens.</p>';
  count();
}
function chosen() { return base.concat(sections.filter(fits), pages, suggestions).filter((p) => p.checked); }
function count() {
  if (prefs.mode === "promos") return; const n = chosen().length; const b = document.getElementById("go"); if (b) { b.textContent = "Scan " + n + (n === 1 ? " section" : " sections"); b.disabled = !n; } }
function listOf(l) { return l === "b" ? base : l === "s" ? sections : l === "p" ? pages : suggestions; }

main.addEventListener("change", async (e) => {
  if (e.target.name === "run") { runMode = e.target.value; guessed = false; render(); return; }
  if (e.target.name === "mode") { prefs.mode = e.target.value; await savePrefs(); render(); return; }
  if (e.target.id === "partSel") { prefs.mode = e.target.value; await savePrefs(); render(); return; }
  if (e.target.id === "partName" || e.target.id === "partWords") { prefs[e.target.id] = e.target.value.trim(); await savePrefs(); render(); return; }
  if (e.target.id === "promoTerms") { prefs.promoTerms = e.target.checked; await savePrefs(); return; }
  if (e.target.id === "openCards") { prefs.cards = e.target.checked; await savePrefs(); return; }
  if (e.target.id === "blurWords") { prefs.blur = e.target.value.trim(); await savePrefs(); return; }
  const i = e.target.getAttribute("data-i"); if (i === null) return;
  const l = e.target.getAttribute("data-list"), item = listOf(l)[+i];
  item.checked = e.target.checked;
  if (l === "s") {
    prefs.off = prefs.off.filter((k) => k !== item.key); prefs.on = prefs.on.filter((k) => k !== item.key);
    if (item.off && item.checked) prefs.on.push(item.key);
    if (!item.off && !item.checked) prefs.off.push(item.key);
    await savePrefs();
  }
  if (l === "b") { prefs.off = prefs.off.filter((k) => k !== "base:" + item.cat); if (!item.checked) prefs.off.push("base:" + item.cat); await savePrefs(); }
  if (l === "x" || l === "p") await saveSite();
  count();
});
main.addEventListener("click", async (e) => {
  const t = e.target;
  if (t.id === "addSec") {
    const name = document.getElementById("newName").value.trim();
    if (!name) { document.getElementById("newName").focus(); return; }
    const c = { key: "c_" + Date.now().toString(36), label: name, words: wordsFrom(name, document.getElementById("newWords").value) };
    prefs.custom.push(c); await savePrefs();
    sections.push(Object.assign({ details: true, custom: true, group: "Your own", checked: true, seen: seenOnPage(c, target.info) }, c));
    render();
  }
  if (t.hasAttribute("data-rm")) {
    const s = sections[+t.getAttribute("data-rm")];
    prefs.custom = prefs.custom.filter((c) => c.key !== s.key); prefs.off = prefs.off.filter((k) => k !== s.key); await savePrefs();
    sections.splice(+t.getAttribute("data-rm"), 1); render();
  }
  if (t.hasAttribute("data-keep")) {
    const s = suggestions.splice(+t.getAttribute("data-keep"), 1)[0]; await saveSite();
    const c = { key: "c_" + Date.now().toString(36), label: s.label, words: wordsFrom(s.label, "") };
    prefs.custom.push(c); await savePrefs();
    sections.push(Object.assign({ details: true, custom: true, group: "Your own", checked: true, seen: s.seen }, c)); render();
  }
  if (t.id === "add") {
    const v = document.getElementById("extra").value.trim();
    try { const u = new URL(v); pages.push({ type: "page", url: u.toString(), cat: "custom", label: "Added by you", sub: u.pathname, checked: true }); await saveSite(); render(); } catch (err) { document.getElementById("extra").focus(); }
  }
  if (t.id === "go" && !SHOW_REVIEW && !SHOW_PARTS) {
    const home = base[0].url, run = document.querySelector('input[name="run"]:checked').value, S = (k) => DEFAULT_SECTIONS.find((x) => x.key === k);
    const find = (sec, extra) => Object.assign({ type: "find", url: home, label: sec.label, cat: sec.key, words: sec.words, not: sec.not || "", popup: !!sec.popup, details: true, help: !!sec.help }, extra || {});
    const list = [{ type: "page", url: home, cat: "homepage", label: "Homepage", details: false }];
    if (info0.menu && info0.menu.length >= 3) list.push({ type: "menu", url: home, cat: "menu", label: "Site menu", menu: info0.menu });
    list.push(find(S("promotions"), prefs.cards !== false ? { cards: true, cardLabel: "Offer", cardLimit: 30, details: false } : {}));
    ["vip", "missions", "tournaments", "shop"].forEach((k) => list.push(find(S(k))));
    if (run === "logged-in") list.push(find(S("deposit")));
    list.push(find(S("terms")));
    RESEARCH_EXTRA.forEach((sec) => list.push(find(sec, { details: false })));
    ["rg", "help", "app"].forEach((k) => list.push(find(S(k), { details: false })));
    // menu entries none of the categories cover (a wheel, refer a friend, a blog…): read for the Other tab
    const extraRe = RESEARCH_EXTRA.map((x) => new RegExp(x.words, "i"));
    suggestions.filter((x) => !extraRe.some((r) => r.test(x.label))).slice(0, 6).forEach((x) => list.push({ type: "find", url: home, label: x.label, cat: "other", words: x.words, not: "", details: true }));
    await chrome.runtime.sendMessage({ type: "scan", kind: "research", tabId: target.id, pages: list, run, skip: [], blur: String(prefs.blur || "").split(",").map((w) => w.trim()).filter((w) => w.length >= 3), site: { host: target.info.host, title: target.info.title, url: target.info.url } });
    showProgress();
    return;
  }
  if (t.id === "go" && partOf() !== "promos" && partOf() !== "review") {
    const k = partOf(), home = base[0].url, run = document.querySelector('input[name="run"]:checked').value;
    let label = PARTS.find((p) => p[0] === k)[1], sec = DEFAULT_SECTIONS.find((x) => x.key === k);
    if (k === "custom") {
      if (!prefs.partName) { const n = document.getElementById("partName"); if (n) n.focus(); return; }
      label = prefs.partName; sec = { words: wordsFrom(prefs.partName, prefs.partWords || ""), not: "" };
    }
    const page = { type: "find", url: home, label, cat: k === "custom" ? "custom" : k, words: sec.words, not: sec.not || "", popup: !!sec.popup, details: true };
    if (k === "tournaments") Object.assign(page, { cards: true, cardLabel: "Tournament", cardLimit: 15 });
    await chrome.runtime.sendMessage({ type: "scan", kind: "part", part: { key: k, label }, tabId: target.id, pages: [page], run, skip: [], blur: String(prefs.blur || "").split(",").map((w) => w.trim()).filter((w) => w.length >= 3), site: { host: target.info.host, title: target.info.title, url: target.info.url } });
    showProgress();
    return;
  }
  if (t.id === "go" && partOf() === "promos") {
    const home = base[0].url, P = DEFAULT_SECTIONS.find((x) => x.key === "promotions"), T = DEFAULT_SECTIONS.find((x) => x.key === "terms");
    const list = [{ type: "find", url: home, label: "Promotions", cat: "promotions", words: P.words, not: P.not || "", cards: true, cardLabel: "Offer", cardLimit: 30, details: false }];
    if (prefs.promoTerms === true) list.push({ type: "find", url: home, label: "Bonus terms", cat: "terms", words: T.words, not: T.not || "", details: true, help: true });
    const run = document.querySelector('input[name="run"]:checked').value;
    await chrome.runtime.sendMessage({ type: "scan", kind: "promos", tabId: target.id, pages: list, run, skip: [], blur: String(prefs.blur || "").split(",").map((w) => w.trim()).filter((w) => w.length >= 3), site: { host: target.info.host, title: target.info.title, url: target.info.url } });
    showProgress();
    return;
  }
  if (t.id === "go") {
    const home = base[0].url;
    const list = chosen().map((p) => p.type ? { type: p.type, url: p.url, label: p.label + (p.sub && p.type === "page" ? " (" + p.sub + ")" : ""), cat: p.cat, menu: p.menu || null, details: p.cat === "current" || p.cat === "custom" }
      : { type: "find", url: home, label: p.label, cat: p.key, words: p.words, not: p.not || "", content: !!p.content, cards: !!p.cards && prefs.cards === true, cardLabel: p.cards || "", promo: p.content ? { words: PROMO.words, not: PROMO.not } : null, popup: !!p.popup, details: !!p.details, help: !!p.help });
    const run = document.querySelector('input[name="run"]:checked').value;
    // sections you left unticked: the planner won't make cards for them, even if another page shows them
    const used = new Set(), skip = new Set();
    chosen().forEach((p) => (KINDS[p.key || p.cat] || []).forEach((k) => used.add(k)));
    base.concat(sections.filter(fits)).filter((p) => !p.checked).forEach((p) => (KINDS[p.key || p.cat] || []).forEach((k) => { if (!used.has(k)) skip.add(k); }));
    const picked = chosen(), has = (key) => picked.some((p) => p.key === key);
    // "Open every promotion" off: no offer cards from the promotions page, only offers you ticked yourself
    if (prefs.cards !== true) {
      ["second", "third", "reload", "cashback", "freespins", "vip", "other_offer"].forEach((k) => skip.add(k));
      if (!has("welcome")) skip.add("welcome");
      if (!has("sports")) skip.add("sports");
    }
    // "Other page" only when you asked for something it would hold (bonus terms, your own sections, pasted links, this page, suggestions)
    if (!picked.some((p) => p.key === "terms" || p.custom || /^s_/.test(p.key || "") || p.cat === "custom" || p.cat === "current")) skip.add("other_page");
    await chrome.runtime.sendMessage({ type: "scan", tabId: target.id, pages: list, run, skip: Array.from(skip), blur: String(prefs.blur || "").split(",").map((w) => w.trim()).filter((w) => w.length >= 3), site: { host: target.info.host, title: target.info.title, url: target.info.url } });
    showProgress();
  }
});

function showProgress() {
  main.innerHTML = '<h2>Scanning</h2><div class="bar"><i id="bar"></i></div><p class="note" id="prog">Starting…</p>' +
    '<div class="col" id="stopBox"><button id="stopKeep">Stop and keep what\'s done</button><button id="stopDiscard" class="quiet">Cancel scan</button></div>';
  const stop = async (mode) => {
    document.getElementById("stopBox").innerHTML = '<p class="note">Stopping after the current step…</p>';
    await chrome.runtime.sendMessage({ type: "stop", mode });
  };
  document.getElementById("stopKeep").onclick = () => stop("keep");
  document.getElementById("stopDiscard").onclick = () => stop("discard");
  const update = (st) => {
    if (!st) return;
    const pct = st.total ? Math.round(100 * (st.done || 0) / st.total) : 0;
    const bar = document.getElementById("bar"); if (bar) bar.style.width = pct + "%";
    const p = document.getElementById("prog"); if (!p) return;
    if (st.state === "running") p.textContent = "Section " + Math.min(st.total, (st.done || 0) + 1) + " of " + st.total + (st.current ? ": " + st.current : "");
    if (st.state === "done") main.innerHTML = '<p class="ok">' + (st.partial ? "Stopped. The " + st.kept + (st.kept === 1 ? " section" : " sections") + " finished so far are in CRM Studio, which has opened in a new tab." : "Done. CRM Studio has opened in a new tab with the scan.") + "</p>";
    if (st.state === "stopped") main.innerHTML = '<p class="ok">' + (st.message ? esc(st.message) : "The scan was cancelled.") + " Click the extension again to start a new scan.</p>";
    if (st.state === "error") main.innerHTML = '<p class="warn">The scan stopped: ' + esc(st.message) + "</p>";
  };
  chrome.storage.local.get("scanStatus").then((r) => update(r.scanStatus));
  chrome.storage.onChanged.addListener((ch) => { if (ch.scanStatus) update(ch.scanStatus.newValue); });
}

(async function start() {
  const { scanStatus } = await chrome.storage.local.get("scanStatus");
  if (scanStatus && scanStatus.state === "running") { document.getElementById("site").textContent = "A scan is running"; showProgress(); return; }
  const stored = (await chrome.storage.sync.get("sectionPrefs")).sectionPrefs;
  if (stored) prefs = { off: stored.off || [], on: stored.on || [], custom: stored.custom || [], cards: stored.cards, blur: stored.blur || "", mode: stored.mode || "review", promoTerms: stored.promoTerms, partName: stored.partName || "", partWords: stored.partWords || "" };
  // ?tab=<id> lets the popup be opened as a normal page for testing.
  const q = new URLSearchParams(location.search).get("tab");
  const tab = q ? await chrome.tabs.get(+q) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!tab || !/^https?:/i.test(tab.url || "")) {
    document.getElementById("site").textContent = "Open a website first";
    main.innerHTML = '<p class="note">Go to the operator\'s website in this tab (turn on your VPN first if you need one), then click the extension again.</p>';
    return;
  }
  try {
    main.innerHTML = '<p class="note">Looking at the page…</p>';
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectSite });
    target = { id: tab.id, info: res.result }; info0 = res.result;
    const ticks = (await chrome.storage.local.get("siteTicks")).siteTicks || {};
    if (ticks[res.result.host]) site = { sugg: ticks[res.result.host].sugg || [], pages: ticks[res.result.host].pages || [] };
    document.getElementById("site").textContent = res.result.host;
    build(res.result);
    const lg = res.result.login;
    if (lg.inScore - lg.outScore >= 2) { runMode = "logged-in"; guessed = "You seem to be logged in (" + lg.inWhy.slice(0, 2).join(", ") + "). Change it if that's wrong."; }
    else if (lg.outScore - lg.inScore >= 2) { runMode = "logged-out"; guessed = "You seem to be logged out (" + lg.outWhy.slice(0, 2).join(", ") + "). Change it if that's wrong."; }
    else guessed = "Couldn't tell if you're logged in. Check the switch.";
    render();
  } catch (err) {
    main.innerHTML = '<p class="warn">Couldn\'t read this page: ' + esc(err.message) + "</p>";
  }
})();
